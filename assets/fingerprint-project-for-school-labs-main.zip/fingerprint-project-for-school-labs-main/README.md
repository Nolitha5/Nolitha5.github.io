# fingerprint-project-for-school-labs
use xampp to host the project on a apache server and sql for database
